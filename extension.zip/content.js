(async () => {
// ─── VARIABLES GLOBALES ─────────────────────────────────────────────────────
let panelExistente = null;
let panelVisible = true;

// Eliminar cualquier panel existente al cargar (limpieza)
const existingPanels = document.querySelectorAll('#__onpe_panel');
existingPanels.forEach(p => p.remove());

  const wait = ms => new Promise(r => setTimeout(r, ms));
  const STORAGE_KEY = 'onpe_snapshots';

  const DEPARTAMENTOS = [
    'AMAZONAS','ÁNCASH','APURÍMAC','AREQUIPA','AYACUCHO',
    'CAJAMARCA','CALLAO','CUSCO','HUANCAVELICA','HUÁNUCO',
    'ICA','JUNÍN','LA LIBERTAD','LAMBAYEQUE','LIMA',
    'LORETO','MADRE DE DIOS','MOQUEGUA','PASCO','PIURA',
    'PUNO','SAN MARTÍN','TACNA','TUMBES','UCAYALI'
  ];

  function getSnapshots() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'); } catch { return {}; }
  }
  function saveSnapshots(d) { localStorage.setItem(STORAGE_KEY, JSON.stringify(d)); }

  // ─── PARSING ──────────────────────────────────────────────────────────────
  function parsePorcentaje(texto) {
    if (!texto) return 0;
    let limpio = texto.trim().replace(/%/g, '').replace(/\s/g, '');
    if (limpio.includes(',') && limpio.includes('.')) {
      const lastComma = limpio.lastIndexOf(',');
      const lastPoint = limpio.lastIndexOf('.');
      if (lastComma > lastPoint) limpio = limpio.replace(/\./g, '').replace(',', '.');
      else limpio = limpio.replace(/,/g, '');
    } else if (limpio.includes(',')) {
      limpio = limpio.replace(',', '.');
    }
    const resultado = parseFloat(limpio);
    return isNaN(resultado) ? 0 : resultado;
  }

  function parseVotos(texto) {
    if (!texto) return 0;
    const limpio = texto.replace(/\D/g, '');
    const resultado = parseInt(limpio, 10);
    return isNaN(resultado) ? 0 : resultado;
  }

  function extraerTexto(elemento) {
    if (!elemento) return '';
    let texto = elemento.textContent || '';
    return texto.replace(/\s+/g, ' ').trim();
  }

  // ─── DOM helpers ──────────────────────────────────────────────────────────
  async function getPanel(timeout = 3000) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeout) {
      const p = document.querySelector('.mat-mdc-select-panel.mdc-menu-surface--open');
      if (p) return p;
      await wait(80);
    }
    return null;
  }

  async function clickOption(selectEl, texto, waitAfter = 1000) {
    if (!selectEl) return false;
    selectEl.click();
    const panel = await getPanel();
    if (!panel) { document.body.click(); await wait(300); return false; }
    for (const opt of panel.querySelectorAll('.mat-mdc-option')) {
      const t = opt.querySelector('.mdc-list-item__primary-text')?.textContent?.trim()
               ?? opt.textContent?.trim();
      if (t && t.toUpperCase() === texto.toUpperCase()) {
        opt.click();
        await wait(waitAfter);
        return true;
      }
    }
    document.body.click(); await wait(300);
    return false;
  }

  function getSelectOptions(selectEl) {
    if (!selectEl) return [];
    const options = [];
    selectEl.click();
    const panel = document.querySelector('.mat-mdc-select-panel.mdc-menu-surface--open');
    if (panel) {
      for (const opt of panel.querySelectorAll('.mat-mdc-option')) {
        const t = opt.querySelector('.mdc-list-item__primary-text')?.textContent?.trim()
                 ?? opt.textContent?.trim();
        if (t && t.toUpperCase() !== 'TODOS') options.push(t);
      }
      document.body.click();
    }
    return options;
  }

  async function waitForData(timeout = 8000, datosAnteriores = null, aceptarCero = false) {
    const t0 = Date.now();
    let intento = 0;
    while (Date.now() - t0 < timeout) {
      intento++;
      const iz = document.querySelector('.tarjeta-candidato--izquierda');
      const de = document.querySelector('.tarjeta-candidato--derecha');
      if (iz && de) {
        const pct1 = parsePorcentaje(extraerTexto(iz.querySelector('.tarjeta-candidato__porcentaje')));
        const pct2 = parsePorcentaje(extraerTexto(de.querySelector('.tarjeta-candidato__porcentaje')));
        const vt1 = parseVotos(extraerTexto(iz.querySelector('.tarjeta-candidato__votos')));
        const vt2 = parseVotos(extraerTexto(de.querySelector('.tarjeta-candidato__votos')));
        const datosValidos = aceptarCero || ((pct1 > 0 || pct2 > 0) && (vt1 > 0 || vt2 > 0));
        if (datosValidos) {
          if (datosAnteriores) {
            const cambiaron = pct1 !== datosAnteriores.pct1 || pct2 !== datosAnteriores.pct2 || vt1 !== datosAnteriores.vt1 || vt2 !== datosAnteriores.vt2;
            if (cambiaron || aceptarCero) {
              console.log(`[ONPE] ✓ Datos ${aceptarCero ? '(aceptando 0%)' : 'cambiaron'} en ${Date.now() - t0}ms`);
              return { pct1, pct2, vt1, vt2 };
            }
          } else {
            console.log(`[ONPE] ✓ Datos cargados en ${Date.now() - t0}ms`);
            return { pct1, pct2, vt1, vt2 };
          }
        }
      }
      await wait(200);
    }
    console.warn(`[ONPE] ✗ Timeout después de ${timeout}ms`);
    return null;
  }

  function leerDatos() {
    const iz = document.querySelector('.tarjeta-candidato--izquierda');
    const de = document.querySelector('.tarjeta-candidato--derecha');
    if (!iz || !de) return null;
    const nom1 = extraerTexto(iz.querySelector('.tarjeta-candidato__nombre'));
    const nom2 = extraerTexto(de.querySelector('.tarjeta-candidato__nombre'));
    const pct1 = parsePorcentaje(extraerTexto(iz.querySelector('.tarjeta-candidato__porcentaje')));
    const pct2 = parsePorcentaje(extraerTexto(de.querySelector('.tarjeta-candidato__porcentaje')));
    const vt1 = parseVotos(extraerTexto(iz.querySelector('.tarjeta-candidato__votos')));
    const vt2 = parseVotos(extraerTexto(de.querySelector('.tarjeta-candidato__votos')));
    if (pct1 === 0 && pct2 === 0 && vt1 === 0 && vt2 === 0) return null;
    return { nom1, pct1, vt1, nom2, pct2, vt2 };
  }

  function leerActas() {
    const secPC = document.querySelector('app-seccion-actas-resumen .version-pc');
    const secMob = document.querySelector('app-seccion-actas-resumen .version-movil');
    const sec = secPC || secMob;
    if (!sec) return null;
    const pctText = (sec.querySelector('.infoprincipal-detalle b')?.textContent || sec.querySelector('.datos_resumen')?.textContent || '').replace(/[^0-9.]/g, '');
    const pctContabilizadas = parseFloat(pctText) || 0;
    const totalText = sec.textContent.match(/Total de actas[:\s]*([\d,]+)/i);
    const totalActas = parseInt((totalText?.[1] || '0').replace(/,/g, '')) || 0;
    const leyendaItems = sec.querySelectorAll('.leyenda li');
    let contabilizadas = 0, paraJEE = 0, pendientes = 0;
    leyendaItems.forEach(li => {
      const txt = li.textContent;
      const num = parseInt((txt.match(/\((\d[\d,]*)\)/) || [])[1]?.replace(/,/g,'') || '0');
      if (/contabilizadas/i.test(txt)) contabilizadas = num;
      else if (/jee|env[ií]o/i.test(txt)) paraJEE = num;
      else if (/pendientes/i.test(txt)) pendientes = num;
    });
    if (!contabilizadas && !paraJEE && !pendientes) {
      sec.querySelectorAll('li').forEach(li => {
        const txt = li.textContent;
        const num = parseInt((txt.match(/\((\d[\d,]*)\)/) || [])[1]?.replace(/,/g,'') || '0');
        if (/contabilizadas/i.test(txt)) contabilizadas = num;
        else if (/jee|env[ií]o/i.test(txt)) paraJEE = num;
        else if (/pendientes/i.test(txt)) pendientes = num;
      });
    }
    const tsEl = sec.querySelector('.actualizado b') || sec.querySelector('.fecha_resumen');
    const tsHora = sec.querySelector('.hora_resumen');
    let tsActas = '';
    if (tsEl) {
      tsActas = tsEl.textContent.trim();
      if (tsHora) tsActas += ' ' + tsHora.textContent.trim();
    }
    return { pctContabilizadas, totalActas, contabilizadas, paraJEE, pendientes, tsActas };
  }

  function updateStatus(msg) {
    const el = document.getElementById('__onpe_status');
    if (el) el.textContent = msg;
    console.log('[ONPE]', msg);
  }

  // ─── capturarTodo ─────────────────────────────────────────────────────────
  async function capturarTodo() {
    const selRegion = document.querySelector('mat-select[formcontrolname="region"]');
    if (!selRegion) { alert('No se encontró el select de región.'); return null; }
    const resultado = { ts: new Date().toISOString(), regions: {}, actas: {} };
    let datosPrevios = null;

    updateStatus('Capturando: GENERAL...');
    await clickOption(selRegion, 'TODOS', 1500);
    await wait(800);
    const datosCargados = await waitForData(8000, null);
    if (datosCargados) {
      await wait(300);
      const gral = leerDatos();
      if (gral) { resultado.regions['__GENERAL__'] = gral; datosPrevios = datosCargados; }
    }
    const actasGral = leerActas();
    if (actasGral) resultado.actas['__GENERAL__'] = actasGral;

    updateStatus('Seleccionando PERÚ...');
    await clickOption(selRegion, 'PERÚ', 1200);
    await wait(500);

    for (let i = 0; i < DEPARTAMENTOS.length; i++) {
      const dep = DEPARTAMENTOS[i];
      updateStatus(`[PERÚ ${i+1}/${DEPARTAMENTOS.length}] ${dep}...`);
      const valRegion = selRegion.querySelector('.mat-mdc-select-value-text')?.textContent?.trim();
      if (!valRegion?.includes('PERÚ')) { await clickOption(selRegion, 'PERÚ', 1000); await wait(500); }
      const selDept = document.querySelector('mat-select[formcontrolname="department"]');
      if (!selDept) continue;
      const ok = await clickOption(selDept, dep, 600);
      if (!ok) continue;
      await wait(500);
      const datosOk = await waitForData(8000, datosPrevios);
      if (datosOk) {
        await wait(400);
        const datos = leerDatos();
        if (datos) { resultado.regions[dep] = datos; datosPrevios = datosOk; }
      }
      const actasDep = leerActas();
      if (actasDep) resultado.actas[dep] = actasDep;
      await wait(300);
    }

    updateStatus('Capturando: EXTRANJERO...');
    await clickOption(selRegion, 'EXTRANJERO', 1500);
    await wait(800);
    const selContinente = document.querySelector('mat-select[formcontrolname="continent"]');
    if (selContinente) {
      const continentes = getSelectOptions(selContinente);
      for (let i = 0; i < continentes.length; i++) {
        const continente = continentes[i];
        updateStatus(`[EXTRANJERO ${i+1}/${continentes.length}] ${continente}...`);
        await clickOption(selContinente, continente, 800);
        await wait(500);
        const selPaisActual = document.querySelector('mat-select[formcontrolname="country"]');
        if (!selPaisActual) continue;
        const paises = getSelectOptions(selPaisActual);
        for (let j = 0; j < paises.length; j++) {
          const pais = paises[j];
          updateStatus(`[${continente} ${j+1}/${paises.length}] ${pais}...`);
          await clickOption(selPaisActual, pais, 800);
          await wait(500);
          const selCiudadActual = document.querySelector('mat-select[formcontrolname="city"]');
          if (selCiudadActual) {
            const ciudades = getSelectOptions(selCiudadActual);
            if (ciudades.length > 0) {
              for (let k = 0; k < ciudades.length; k++) {
                const ciudad = ciudades[k];
                updateStatus(`[${pais} ${k+1}/${ciudades.length}] ${ciudad}...`);
                await clickOption(selCiudadActual, ciudad, 600);
                await wait(500);
                const datosOk = await waitForData(8000, datosPrevios, true);
                await wait(300);
                const datos = leerDatos();
                const key = `EXTRANJERO_${continente}_${pais}_${ciudad}`;
                if (datos) {
                  resultado.regions[key] = datos;
                  datosPrevios = { pct1: datos.pct1, pct2: datos.pct2, vt1: datos.vt1, vt2: datos.vt2 };
                } else {
                  resultado.regions[key] = { nom1: 'KEIKO SOFIA FUJIMORI HIGUCHI', pct1: 0, vt1: 0, nom2: 'ROBERTO HELBERT SANCHEZ PALOMINO', pct2: 0, vt2: 0 };
                }
                const actasData = leerActas();
                if (actasData) resultado.actas[key] = actasData;
                await wait(200);
              }
            } else {
              const datosOk = await waitForData(8000, datosPrevios, true);
              await wait(300);
              const datos = leerDatos();
              const key = `EXTRANJERO_${continente}_${pais}`;
              if (datos) {
                resultado.regions[key] = datos;
                datosPrevios = { pct1: datos.pct1, pct2: datos.pct2, vt1: datos.vt1, vt2: datos.vt2 };
              } else {
                resultado.regions[key] = { nom1: 'KEIKO SOFIA FUJIMORI HIGUCHI', pct1: 0, vt1: 0, nom2: 'ROBERTO HELBERT SANCHEZ PALOMINO', pct2: 0, vt2: 0 };
              }
              const actasData = leerActas();
              if (actasData) resultado.actas[key] = actasData;
            }
          } else {
            const datosOk = await waitForData(8000, datosPrevios, true);
            await wait(300);
            const datos = leerDatos();
            const key = `EXTRANJERO_${continente}_${pais}`;
            if (datos) {
              resultado.regions[key] = datos;
              datosPrevios = { pct1: datos.pct1, pct2: datos.pct2, vt1: datos.vt1, vt2: datos.vt2 };
            } else {
              resultado.regions[key] = { nom1: 'KEIKO SOFIA FUJIMORI HIGUCHI', pct1: 0, vt1: 0, nom2: 'ROBERTO HELBERT SANCHEZ PALOMINO', pct2: 0, vt2: 0 };
            }
            const actasData = leerActas();
            if (actasData) resultado.actas[key] = actasData;
          }
          await wait(200);
        }
      }
    }

    await clickOption(selRegion, 'TODOS', 500);
    const snapshots = getSnapshots();
    if (!snapshots['snap']) snapshots['snap'] = [];
    snapshots['snap'].push(resultado);
    if (snapshots['snap'].length > 2) snapshots['snap'].shift();
    saveSnapshots(snapshots);
    const totalRegiones = Object.keys(resultado.regions).length;
    updateStatus(`✓ Listo — ${totalRegiones} entradas guardadas`);
    return resultado;
  }

  // ─── RENDER ───────────────────────────────────────────────────────────────
  function fmt(n) { return (n||0).toLocaleString('es-PE'); }
  function fmtP(n) { return (n||0).toFixed(3)+'%'; }
  function sc(n) { return n>0?'#4ade80':n<0?'#f87171':'#999'; }
  function ss(n) { return n>0?'+':''; }

  function renderActasBlock(actas) {
    if (!actas) return '';
    const pct = (actas.pctContabilizadas || 0).toFixed(3);
    const total = fmt(actas.totalActas);
    const cont = fmt(actas.contabilizadas);
    const jee = fmt(actas.paraJEE);
    const pend = fmt(actas.pendientes);
    const barW = Math.min(actas.pctContabilizadas || 0, 100).toFixed(2);
    const ts = actas.tsActas ? `<span style="color:#444;font-size:8px">${actas.tsActas}</span>` : '';
    return `
      <div style="background:#0d0d0d;border-radius:5px;padding:6px 8px;margin-bottom:5px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
          <span style="font-size:9px;color:#888;font-weight:600;text-transform:uppercase;letter-spacing:.4px">📋 Actas</span>
          ${ts}
        </div>
        <div style="display:flex;align-items:baseline;gap:6px;margin-bottom:4px">
          <span style="font-size:14px;font-weight:700;color:#facc15">${pct}%</span>
          <span style="font-size:9px;color:#555">contabilizadas · total ${total}</span>
        </div>
        <div style="background:#1a1a1a;border-radius:3px;height:4px;margin-bottom:5px;overflow:hidden">
          <div style="height:100%;width:${barW}%;background:linear-gradient(90deg,#facc15,#f59e0b);border-radius:3px"></div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:3px;font-size:8.5px;text-align:center">
          <div style="background:#111;border-radius:3px;padding:3px 2px"><div style="color:#4ade80;font-weight:700">${cont}</div><div style="color:#444;margin-top:1px">Cont.</div></div>
          <div style="background:#111;border-radius:3px;padding:3px 2px"><div style="color:#60a5fa;font-weight:700">${jee}</div><div style="color:#444;margin-top:1px">JEE</div></div>
          <div style="background:#111;border-radius:3px;padding:3px 2px"><div style="color:#888;font-weight:700">${pend}</div><div style="color:#444;margin-top:1px">Pend.</div></div>
        </div>
      </div>`;
  }

  function renderPanel() {
    const content = document.getElementById('__onpe_content');
    if (!content) return;
    const snaps = (getSnapshots()['snap'] || []);
    if (!snaps.length) {
      content.innerHTML = '<p style="color:#666;font-size:12px;text-align:center;padding:16px">Sin datos.<br>Presiona ⟳ para capturar.</p>';
      return;
    }
    const curr = snaps[snaps.length - 1];
    const prev = snaps.length >= 2 ? snaps[snaps.length - 2] : null;
    let html = `
      <div style="font-size:10px;color:#555;margin-bottom:2px">Actual: ${new Date(curr.ts).toLocaleString('es-PE')}</div>
      ${prev ? `<div style="font-size:10px;color:#555;margin-bottom:8px">Anterior: ${new Date(prev.ts).toLocaleString('es-PE')}</div>` : '<div style="font-size:10px;color:#444;margin-bottom:8px">Sin comparativa aún</div>'}
    `;
    for (const reg of Object.keys(curr.regions)) {
      const c = curr.regions[reg];
      const p = prev?.regions[reg];
      const actas = curr.actas?.[reg] || null;
      let label = reg;
      if (reg === '__GENERAL__') label = '🇵🇪 GENERAL';
      else if (reg.startsWith('EXTRANJERO_')) {
        const parts = reg.split('_');
        if (parts.length === 4) label = `🌍 ${parts[1]} → ${parts[2]} → ${parts[3]}`;
        else if (parts.length === 3) label = `🌍 ${parts[1]} → ${parts[2]}`;
      }
      const keiko = c.nom1.toUpperCase().includes('FUJIMORI') ? {pct:c.pct1,vt:c.vt1} : {pct:c.pct2,vt:c.vt2};
      const sanchez = c.nom1.toUpperCase().includes('SANCHEZ') ? {pct:c.pct1,vt:c.vt1} : {pct:c.pct2,vt:c.vt2};
      const kp = p ? (p.nom1.toUpperCase().includes('FUJIMORI') ? {pct:p.pct1,vt:p.vt1} : {pct:p.pct2,vt:p.vt2}) : null;
      const sp = p ? (p.nom1.toUpperCase().includes('SANCHEZ') ? {pct:p.pct1,vt:p.vt1} : {pct:p.pct2,vt:p.vt2}) : null;
      const dKpct = kp != null ? keiko.pct - kp.pct : null;
      const dKvt = kp != null ? keiko.vt - kp.vt : null;
      const dSpct = sp != null ? sanchez.pct - sp.pct : null;
      const dSvt = sp != null ? sanchez.vt - sp.vt : null;
      const diffPct = (keiko.pct - sanchez.pct).toFixed(3);
      const diffVt = Math.abs(keiko.vt - sanchez.vt);
      const ganadorColor = keiko.pct > sanchez.pct ? '#f97316' : '#3b82f6';
      html += `
      <div style="background:#141414;border-radius:8px;padding:9px 11px;margin-bottom:7px;border-left:3px solid ${ganadorColor}">
        <div style="font-size:11px;font-weight:700;color:#e5e5e5;margin-bottom:6px">${label}</div>
        ${renderActasBlock(actas)}
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:5px">
          <div style="background:#0d0d0d;border-radius:5px;padding:5px 7px">
            <div style="font-size:9px;color:#f97316;font-weight:600;margin-bottom:1px">KEIKO</div>
            <div style="font-size:13px;font-weight:700;color:#f97316">${fmtP(keiko.pct)}</div>
            <div style="font-size:10px;color:#c2410c">${fmt(keiko.vt)} vt</div>
            ${dKpct!==null?`<div style="font-size:9px;color:${sc(dKpct)};margin-top:2px">${ss(dKpct)}${dKpct.toFixed(3)}pp · ${ss(dKvt)}${fmt(dKvt)} vt</div>`:''}
          </div>
          <div style="background:#0d0d0d;border-radius:5px;padding:5px 7px">
            <div style="font-size:9px;color:#60a5fa;font-weight:600;margin-bottom:1px">SANCHEZ</div>
            <div style="font-size:13px;font-weight:700;color:#60a5fa">${fmtP(sanchez.pct)}</div>
            <div style="font-size:10px;color:#1d4ed8">${fmt(sanchez.vt)} vt</div>
            ${dSpct!==null?`<div style="font-size:9px;color:${sc(dSpct)};margin-top:2px">${ss(dSpct)}${dSpct.toFixed(3)}pp · ${ss(dSvt)}${fmt(dSvt)} vt</div>`:''}
          </div>
        </div>
        <div style="font-size:10px;color:#555;border-top:1px solid #1f1f1f;padding-top:4px">
          Diferencia: <span style="color:#e5e5e5;font-weight:600">${parseFloat(diffPct)>=0?'+':''}${diffPct}pp</span>
          · <span style="color:#e5e5e5;font-weight:600">${fmt(diffVt)} votos</span>
        </div>
      </div>`;
    }
    content.innerHTML = html;
  }

  function extractCandidatos(regionData) {
    if (!regionData) return { keiko: { pct: 0, vt: 0 }, sanchez: { pct: 0, vt: 0 } };
    const n1 = (regionData.nom1 || '').toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
    const esKeiko1 = n1.includes('FUJIMORI') || n1.includes('KEIKO');
    if (esKeiko1) {
      return { keiko: { pct: regionData.pct1, vt: regionData.vt1, nom: regionData.nom1 }, sanchez: { pct: regionData.pct2, vt: regionData.vt2, nom: regionData.nom2 } };
    } else {
      return { keiko: { pct: regionData.pct2, vt: regionData.vt2, nom: regionData.nom2 }, sanchez: { pct: regionData.pct1, vt: regionData.vt1, nom: regionData.nom1 } };
    }
  }

  // ─── GENERAR HTML (resumido, igual que antes) ─────────────────────────────
  function generarHTML(snaps) {
    const curr = snaps[snaps.length - 1];
    const prev = snaps.length >= 2 ? snaps[snaps.length - 2] : null;
    const fmtH = n => (n||0).toLocaleString('es-PE');
    const fmtPH = n => (n||0).toFixed(3)+'%';
    const scH = n => n>0?'#4ade80':n<0?'#f87171':'#666';
    const ssH = n => n>0?'+':'';
    const regs = Object.keys(curr.regions);
    const peruanas = regs.filter(r => r === '__GENERAL__' || !r.startsWith('EXTRANJERO_'));
    const extranjeras = regs.filter(r => r.startsWith('EXTRANJERO_'));
    const allRegs = [...peruanas, ...extranjeras];
    let rows = '';
    for (const reg of allRegs) {
      const { keiko, sanchez } = extractCandidatos(curr.regions[reg]);
      const prevData = prev?.regions[reg];
      const { keiko: kp, sanchez: sp } = prevData ? extractCandidatos(prevData) : { keiko: null, sanchez: null };
      const actas = curr.actas?.[reg] || null;
      let label = reg;
      let isGeneral = reg === '__GENERAL__';
      let isExtranjero = reg.startsWith('EXTRANJERO_');
      if (isGeneral) label = '🇵🇪 GENERAL';
      else if (isExtranjero) {
        const parts = reg.split('_');
        if (parts.length === 4) label = `🌍 ${parts[1]} → ${parts[2]} → ${parts[3]}`;
        else if (parts.length === 3) label = `🌍 ${parts[1]} → ${parts[2]}`;
      }
      const dKpct = kp ? keiko.pct - kp.pct : null;
      const dSpct = sp ? sanchez.pct - sp.pct : null;
      const diffPct = keiko.pct - sanchez.pct;
      const diffVt = Math.abs(keiko.vt - sanchez.vt);
      const lider = diffPct >= 0 ? 'keiko' : 'sanchez';
      const barKPct = Math.max(0, Math.min(100, keiko.pct));
      const barSPct = Math.max(0, Math.min(100, sanchez.pct));
      const actasPct = actas ? (actas.pctContabilizadas||0).toFixed(1) : '—';
      const actasBar = actas ? Math.min(actas.pctContabilizadas||0, 100).toFixed(2) : 0;
      const actasCont = actas ? fmtH(actas.contabilizadas) : '—';
      const actasJEE = actas ? fmtH(actas.paraJEE) : '—';
      const actasPend = actas ? fmtH(actas.pendientes) : '—';
      const rowClass = isGeneral ? 'row-general' : (isExtranjero ? 'row-extranjero' : 'row-region');
      rows += `
      <tr class="${rowClass}" data-lider="${lider}">
        <td class="td-region"><span class="region-badge">${label}</span></td>
        <td class="td-candidate keiko-col"><div class="cand-pct keiko-pct">${fmtPH(keiko.pct)}</div><div class="cand-vt">${fmtH(keiko.vt)}</div>${dKpct!==null ? `<div class="cand-delta" style="color:${scH(dKpct)}">${ssH(dKpct)}${dKpct.toFixed(3)}pp</div>` : ''}</td>
        <td class="td-candidate sanchez-col"><div class="cand-pct sanchez-pct">${fmtPH(sanchez.pct)}</div><div class="cand-vt">${fmtH(sanchez.vt)}</div>${dSpct!==null ? `<div class="cand-delta" style="color:${scH(dSpct)}">${ssH(dSpct)}${dSpct.toFixed(3)}pp</div>` : ''}</td>
        <td class="td-bar"><div class="bar-container"><div class="bar-k" style="width:${(barKPct/2).toFixed(2)}%"></div><div class="bar-mid"></div><div class="bar-s" style="width:${(barSPct/2).toFixed(2)}%"></div></div><div class="bar-labels"><span class="keiko-text">${fmtPH(keiko.pct)}</span><span class="sanchez-text">${fmtPH(sanchez.pct)}</span></div></td>
        <td class="td-diff" style="color:${diffPct>=0?'#f97316':'#60a5fa'}"><div class="diff-pp">${diffPct>=0?'+':''}${diffPct.toFixed(3)}pp</div><div class="diff-vt">${fmtH(diffVt)} vt</div></td>
        <td class="td-actas"><div class="actas-wrap"><div class="actas-top"><span class="actas-big">${actasPct}%</span><div class="actas-mini-bar"><div class="actas-mini-fill" style="width:${actasBar}%"></div></div></div><div class="actas-counts"><span>✅ ${actasCont}</span><span>📤 ${actasJEE}</span><span>⏳ ${actasPend}</span></div></div></td>
      </tr>`;
    }
    const tsActual = new Date(curr.ts).toLocaleString('es-PE');
    const tsAnterior = prev ? new Date(prev.ts).toLocaleString('es-PE') : null;
    const gen = curr.regions['__GENERAL__'];
    let heroHTML = '';
    if (gen) {
      const { keiko: gk, sanchez: gs } = extractCandidatos(gen);
      const actasGen = curr.actas?.['__GENERAL__'];
      const gDiff = (gk.pct - gs.pct).toFixed(3);
      const gDiffVt = Math.abs(gk.vt - gs.vt);
      heroHTML = `
        <div class="hero">
          <div class="hero-candidate keiko-side"><div class="hero-name">KEIKO FUJIMORI</div><div class="hero-pct keiko-color">${fmtPH(gk.pct)}</div><div class="hero-vt">${fmtH(gk.vt)} votos</div></div>
          <div class="hero-vs"><div class="vs-text">VS</div><div class="vs-diff" style="color:${gDiff>=0?'#f97316':'#60a5fa'}">${gDiff>=0?'+':''}${gDiff}pp</div><div class="vs-vt">${fmtH(gDiffVt)} votos</div>${actasGen ? `<div class="vs-actas">${(actasGen.pctContabilizadas||0).toFixed(1)}% actas</div>` : ''}</div>
          <div class="hero-candidate sanchez-side"><div class="hero-name">ROBERTO SÁNCHEZ</div><div class="hero-pct sanchez-color">${fmtPH(gs.pct)}</div><div class="hero-vt">${fmtH(gs.vt)} votos</div></div>
        </div>
        <div class="hero-bar"><div class="hero-bar-k" style="width:${Math.max(0,Math.min(gk.pct,100)).toFixed(2)}%"></div></div>`;
    }
    // NOTA: Aquí va TODO el HTML/CSS que ya tenías (es muy largo, lo omito para no saturar)
    // Usa el mismo return que tenías antes con todo el CSS y estructura
    return `<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"><title>ONPE Monitor</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600;700&family=IBM+Plex+Sans:wght@400;500;700&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#080808;--bg1:#0f0f0f;--bg2:#161616;--bg3:#1e1e1e;--border:#242424;--text:#e8e8e8;--muted:#555;--dim:#333;--keiko:#f97316;--keiko-d:#c2410c;--keiko-bg:rgba(249,115,22,0.08);--sanchez:#3b82f6;--sanchez-d:#1d4ed8;--sanchez-bg:rgba(59,130,246,0.08);--gold:#f59e0b;--green:#4ade80;--purple:#a855f7;--font-mono:'IBM Plex Mono',monospace;--font-sans:'IBM Plex Sans',system-ui,sans-serif}
body{background:var(--bg);color:var(--text);font-family:var(--font-sans);min-height:100vh}
.page-header{background:var(--bg1);border-bottom:1px solid var(--border);padding:20px 32px 16px;position:sticky;top:0;z-index:100}
.header-top{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;flex-wrap:wrap}
.header-title{font-family:var(--font-mono);font-size:18px;font-weight:700}
.header-title span{color:var(--gold)}
.header-meta{font-family:var(--font-mono);font-size:10px;color:var(--muted);margin-top:4px;display:flex;gap:16px;flex-wrap:wrap}
.badge-live{display:inline-flex;align-items:center;gap:5px;background:rgba(74,222,128,0.12);border:1px solid rgba(74,222,128,0.25);color:var(--green);font-size:10px;font-family:var(--font-mono);font-weight:700;padding:3px 8px;border-radius:4px}
.badge-live::before{content:'';width:6px;height:6px;border-radius:50%;background:var(--green);animation:pulse 1.5s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}
.hero-wrap{padding:24px 32px 0}
.hero{display:grid;grid-template-columns:1fr auto 1fr;background:var(--bg1);border:1px solid var(--border);border-radius:12px;overflow:hidden}
.hero-candidate{padding:20px 24px}
.keiko-side{background:var(--keiko-bg);border-right:1px solid var(--border)}
.sanchez-side{background:var(--sanchez-bg);border-left:1px solid var(--border);text-align:right}
.hero-name{font-family:var(--font-mono);font-size:10px;font-weight:700;letter-spacing:1.5px;color:var(--muted);margin-bottom:6px}
.hero-pct{font-family:var(--font-mono);font-size:32px;font-weight:700;line-height:1;margin-bottom:4px}
.keiko-color{color:var(--keiko)}
.sanchez-color{color:var(--sanchez)}
.hero-vt{font-size:12px;color:var(--muted);font-family:var(--font-mono)}
.hero-vs{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:16px 20px;gap:4px}
.vs-text{font-family:var(--font-mono);font-size:10px;color:var(--dim);letter-spacing:2px}
.vs-diff{font-family:var(--font-mono);font-size:16px;font-weight:700}
.vs-vt{font-size:10px;color:var(--muted);font-family:var(--font-mono)}
.vs-actas{font-size:10px;color:var(--gold);font-family:var(--font-mono);margin-top:4px}
.hero-bar{height:5px;background:var(--sanchez);border-radius:0 0 12px 12px;overflow:hidden;margin:0 0 16px}
.hero-bar-k{height:100%;background:var(--keiko)}
.table-wrap{padding:16px 32px 40px;overflow-x:auto}
.filter-bar{display:flex;align-items:center;gap:8px;margin-bottom:12px;flex-wrap:wrap}
.filter-btn{background:var(--bg2);border:1px solid var(--border);color:var(--muted);font-family:var(--font-mono);font-size:10px;padding:5px 10px;border-radius:5px;cursor:pointer}
.filter-btn:hover,.filter-btn.active{background:var(--bg3);color:var(--text);border-color:var(--muted)}
.filter-btn.keiko-btn.active{border-color:var(--keiko);color:var(--keiko)}
.filter-btn.sanchez-btn.active{border-color:var(--sanchez);color:var(--sanchez)}
.filter-count{font-size:9px;color:var(--dim);margin-left:auto;font-family:var(--font-mono)}
table{width:100%;border-collapse:separate;border-spacing:0 3px;font-family:var(--font-mono);font-size:11px;min-width:700px}
thead th{background:var(--bg1);color:var(--muted);font-size:9px;text-transform:uppercase;letter-spacing:.8px;padding:8px 10px;text-align:left;font-weight:600;position:sticky;top:0;border-bottom:1px solid var(--border)}
thead th.keiko-col{color:var(--keiko)}
thead th.sanchez-col{color:var(--sanchez)}
.row-general td,.row-region td,.row-extranjero td{background:var(--bg1);padding:10px}
.row-general td:first-child{border-radius:6px 0 0 6px;border-left:3px solid var(--gold)}
.row-region[data-lider="keiko"] td:first-child{border-radius:6px 0 0 6px;border-left:3px solid var(--keiko)}
.row-region[data-lider="sanchez"] td:first-child{border-radius:6px 0 0 6px;border-left:3px solid var(--sanchez)}
.row-extranjero td:first-child{border-radius:6px 0 0 6px;border-left:3px solid var(--purple)}
.row-general td:last-child,.row-region td:last-child,.row-extranjero td:last-child{border-radius:0 6px 6px 0}
.row-general td{background:var(--bg2)}
.row-general .region-badge{color:var(--gold);font-weight:700}
.row-extranjero .region-badge{color:var(--purple);font-size:10px}
.td-region{width:200px}
.region-badge{font-size:11px;font-weight:700;color:var(--text)}
.cand-pct{font-size:13px;font-weight:700;line-height:1.2}
.keiko-pct{color:var(--keiko)}
.sanchez-pct{color:var(--sanchez)}
.cand-vt{font-size:9px;color:var(--muted);margin-top:1px}
.cand-delta{font-size:9px;margin-top:2px}
.td-bar{width:160px}
.bar-container{display:flex;height:5px;background:var(--bg3);border-radius:3px;overflow:hidden;gap:1px;margin-bottom:3px}
.bar-k{background:var(--keiko);border-radius:3px 0 0 3px}
.bar-mid{width:1px;background:var(--bg)}
.bar-s{background:var(--sanchez);border-radius:0 3px 3px 0}
.bar-labels{display:flex;justify-content:space-between;font-size:8px;color:var(--muted)}
.td-diff{text-align:right;white-space:nowrap}
.diff-pp{font-size:12px;font-weight:700}
.diff-vt{font-size:9px;color:var(--muted);margin-top:1px}
.td-actas{white-space:nowrap}
.actas-top{display:flex;align-items:center;gap:7px;margin-bottom:3px}
.actas-big{font-size:12px;font-weight:700;color:var(--gold)}
.actas-mini-bar{flex:1;height:3px;background:var(--bg3);border-radius:2px;overflow:hidden;min-width:50px}
.actas-mini-fill{height:100%;background:linear-gradient(90deg,var(--gold),#f59e0b)}
.actas-counts{display:flex;gap:6px;font-size:8px;color:var(--dim)}
.page-footer{border-top:1px solid var(--border);padding:16px 32px;font-size:10px;color:var(--dim);font-family:var(--font-mono);display:flex;gap:24px}
.search-input{background:var(--bg2);border:1px solid var(--border);color:var(--text);font-family:var(--font-mono);font-size:11px;padding:5px 10px;border-radius:5px;outline:none;width:180px}
.hidden{display:none!important}
</style></head><body>
<header class="page-header"><div class="header-top"><div><div class="header-title">🗳 <span>ONPE</span> Monitor — Segunda Vuelta 2026</div><div class="header-meta"><span>📅 Actual: <strong style="color:#888">${tsActual}</strong></span>${tsAnterior ? `<span>⏱ Anterior: <strong style="color:#888">${tsAnterior}</strong></span>` : ''}</div></div><div class="badge-live">EN VIVO</div></div></header>
<div class="hero-wrap">${heroHTML}</div>
<div class="table-wrap"><div class="filter-bar"><button class="filter-btn active" onclick="filtrar('all',this)">Todas</button><button class="filter-btn keiko-btn" onclick="filtrar('keiko',this)">▲ KEIKO gana</button><button class="filter-btn sanchez-btn" onclick="filtrar('sanchez',this)">▲ SÁNCHEZ gana</button><input class="search-input" type="text" placeholder="Buscar región…" oninput="buscar(this.value)"><span class="filter-count" id="row-count">${allRegs.length} regiones</span></div>
<table><thead><tr><th>Región</th><th class="keiko-col">KEIKO %</th><th class="sanchez-col">SÁNCHEZ %</th><th>Distribución</th><th style="text-align:right">Diferencia</th><th>Actas</th></tr></thead><tbody id="tbody">${rows}</tbody></table></div>
<footer class="page-footer"><span>Fuente: ONPE</span><span>Generado: ${tsActual}</span></footer>
<script>let currentFilter='all';let currentSearch='';function updateRows(){const rows=document.querySelectorAll('#tbody tr');let visible=0;rows.forEach(row=>{const lider=row.dataset.lider;const region=row.querySelector('.region-badge')?.textContent?.toLowerCase()||'';const matchF=currentFilter==='all'||lider===currentFilter;const matchS=!currentSearch||region.includes(currentSearch.toLowerCase());if(matchF&&matchS){row.classList.remove('hidden');visible++}else row.classList.add('hidden')});document.getElementById('row-count').textContent=visible+' regiones'}function filtrar(tipo,btn){currentFilter=tipo;document.querySelectorAll('.filter-btn').forEach(b=>b.classList.remove('active'));btn.classList.add('active');updateRows()}function buscar(val){currentSearch=val;updateRows()}<\/script>
</body></html>`;
  }

  // ─── FUNCIÓN PARA CREAR/MOSTRAR PANEL ─────────────────────────────────────
  function crearOMostrarPanel() {
   if (panelExistente && document.getElementById('__onpe_panel')) {
    panelExistente.style.display = 'flex';
    panelVisible = true;
    return panelExistente;
  }
  
  // Limpiar cualquier panel huérfano
  const oldPanels = document.querySelectorAll('#__onpe_panel');
  oldPanels.forEach(p => p.remove());
  
  // Crear nuevo panel
  panelExistente = document.createElement('div');
  panelExistente.id = '__onpe_panel';
  panelExistente.style.cssText = `position:fixed;top:10px;right:10px;width:290px;max-height:92vh;background:#0a0a0a;border:1px solid #222;border-radius:12px;z-index:99999;font-family:sans-serif;display:flex;flex-direction:column;box-shadow:0 8px 40px rgba(0,0,0,0.8);`;
  
    panel.innerHTML = `
      <div style="padding:10px 14px;border-bottom:1px solid #1a1a1a;display:flex;align-items:center;justify-content:space-between;flex-shrink:0">
        <div>
          <div style="font-size:13px;font-weight:700;color:#fff">🗳 ONPE Monitor</div>
          <div id="__onpe_status" style="font-size:10px;color:#555;margin-top:1px">Listo</div>
        </div>
        <button id="__onpe_btn_close" style="background:none;border:none;color:#444;font-size:18px;cursor:pointer;line-height:1">✕</button>
      </div>
      <div style="padding:8px 10px;border-bottom:1px solid #111;display:flex;gap:6px;flex-shrink:0">
        <button id="__onpe_btn_upd" style="flex:1;background:#1d4ed8;border:none;color:#fff;padding:7px;border-radius:7px;cursor:pointer;font-size:11px;font-weight:600">⟳ Actualizar todo</button>
        <button id="__onpe_btn_exp" style="background:#141414;border:1px solid #2a2a2a;color:#888;padding:7px 10px;border-radius:7px;cursor:pointer;font-size:11px" title="Exportar JSON">↓</button>
        <button id="__onpe_btn_html" style="background:#141414;border:1px solid #2a2a2a;color:#888;padding:7px 10px;border-radius:7px;cursor:pointer;font-size:11px" title="Exportar HTML">🌐</button>
        <button id="__onpe_btn_clr" style="background:#141414;border:1px solid #2a2a2a;color:#888;padding:7px 10px;border-radius:7px;cursor:pointer;font-size:11px" title="Borrar datos">🗑</button>
      </div>
      <div id="__onpe_content" style="overflow-y:auto;padding:10px;flex:1;min-height:0"></div>
    `;
    document.body.appendChild(panel);

    // Botón cerrar - solo OCULTA, no elimina
    document.getElementById('__onpe_btn_close').onclick = () => {
      panel.style.display = 'none';
    };

    document.getElementById('__onpe_btn_upd').onclick = async () => {
      const btn = document.getElementById('__onpe_btn_upd');
      btn.disabled = true; btn.textContent = '⏳ Capturando...'; btn.style.background = '#374151';
      try { await capturarTodo(); renderPanel(); }
      catch(e) { updateStatus('Error: ' + e.message); console.error(e); }
      finally { btn.disabled=false; btn.textContent='⟳ Actualizar todo'; btn.style.background='#1d4ed8'; }
    };

    document.getElementById('__onpe_btn_exp').onclick = () => {
      const snaps = getSnapshots()['snap'] || [];
      if (!snaps.length) { alert('Sin datos para exportar.'); return; }
      const blob = new Blob([JSON.stringify(snaps, null, 2)], {type:'application/json'});
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `onpe_${new Date().toISOString().slice(0,19).replace(/:/g,'-')}.json`;
      a.click();
    };

    document.getElementById('__onpe_btn_html').onclick = () => {
      const snaps = getSnapshots()['snap'] || [];
      if (!snaps.length) { alert('Sin datos para exportar.'); return; }
      const html = generarHTML(snaps);
      const blob = new Blob([html], {type:'text/html;charset=utf-8'});
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `onpe_${new Date().toISOString().slice(0,19).replace(/:/g,'-')}.html`;
      a.click();
    };

    document.getElementById('__onpe_btn_clr').onclick = () => {
      if (confirm('¿Borrar snapshots?')) { localStorage.removeItem(STORAGE_KEY); renderPanel(); updateStatus('Borrado'); }
    };

  document.body.appendChild(panelExistente);
  panelVisible = true;
  renderPanel();
  return panelExistente;
  }

  // ─── LISTENERS DE LA EXTENSIÓN (DENTRO DEL IIFE) ──────────────────────────
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      console.log('[ONPE] Mensaje recibido:', request.action);
      switch (request.action) {
        case 'togglePanel': {
        const panel = document.getElementById('__onpe_panel');
            if (!panel) {
                // No existe, crearlo
                crearOMostrarPanel();
                sendResponse({ status: 'created', visible: true });
            } else {
                // Existe, alternar visibilidad
                const isVisible = panel.style.display !== 'none';
                panel.style.display = isVisible ? 'none' : 'flex';
                panelVisible = !isVisible;
                sendResponse({ status: 'toggled', visible: !isVisible });
            }
            break;
        }
        case 'captureAll': {
          crearOMostrarPanel();
          const btn = document.getElementById('__onpe_btn_upd');
          if (btn && !btn.disabled) btn.click();
          sendResponse({ status: 'capturing' });
          break;
        }
        case 'exportJSON': {
          const btn = document.getElementById('__onpe_btn_exp');
          if (btn) btn.click();
          sendResponse({ status: 'exported' });
          break;
        }
        case 'exportHTML': {
          const btn = document.getElementById('__onpe_btn_html');
          if (btn) btn.click();
          sendResponse({ status: 'exported' });
          break;
        }
        case 'clearData': {
          localStorage.removeItem(STORAGE_KEY);
          const panel = document.getElementById('__onpe_panel');
          if (panel) renderPanel();
          sendResponse({ status: 'cleared' });
          break;
        }
        case 'getStatus': {
          const snaps = (getSnapshots()['snap'] || []);
          const curr = snaps[snaps.length - 1];
          sendResponse({
            hasData: snaps.length > 0,
            count: curr ? Object.keys(curr.regions).length : 0
          });
          break;
        }
      }
      return true;
    });
  }

  // ─── INICIALIZAR AL CARGAR ────────────────────────────────────────────────
  crearOMostrarPanel();

})();