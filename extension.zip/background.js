// Cuando se hace click en el ícono, inyectar content script si no existe
chrome.action.onClicked.addListener(async (tab) => {
  // Esto no funciona con popup, pero lo dejamos por si acaso
});

// Inyectar automáticamente al cargar la página
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url?.includes('resultadosegundavuelta.onpe.gob.pe')) {
    chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ['content.js']
    }).catch(e => console.log('Ya inyectado:', e.message));
  }
});