document.addEventListener('DOMContentLoaded', async () => {
  const statusEl = document.getElementById('status');
  
  // Verificar si estamos en la página correcta
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const isOnpe = tab.url && tab.url.includes('resultadosegundavuelta.onpe.gob.pe');
  
  if (!isOnpe) {
    statusEl.textContent = '⚠ Abre la página de ONPE primero';
    statusEl.classList.add('offline');
    document.querySelectorAll('button').forEach(b => b.disabled = true);
    return;
  }
  
  // Intentar inyectar content script por si no está
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js']
    });
    // Esperar un momento a que se inicialice
    await new Promise(r => setTimeout(r, 500));
  } catch (e) {
    console.log('Script ya estaba inyectado o error:', e.message);
  }
  

  // Verificar si hay datos guardados (enviando mensaje a content.js)
  try {
    const result = await chrome.tabs.sendMessage(tab.id, { action: 'getStatus' });
    if (result && result.hasData) {
      statusEl.textContent = `✓ ${result.count} regiones capturadas`;
    } else {
      statusEl.textContent = 'Sin datos aún. Presiona ⟳ Capturar';
    }
  } catch (e) {
    statusEl.textContent = '⚠ No se pudo conectar con la página';
    statusEl.classList.add('offline');
  }

  
  
  // ─── BOTONES ──────────────────────────────────────────────────────────────
  
  // Mostrar/Ocultar panel
  document.getElementById('btn-show').onclick = async () => {
    await chrome.tabs.sendMessage(tab.id, { action: 'togglePanel' });
    window.close();
  };
  
  // Capturar datos
  document.getElementById('btn-capture').onclick = async () => {
    statusEl.textContent = '⏳ Capturando... (puede tardar varios minutos)';
    await chrome.tabs.sendMessage(tab.id, { action: 'captureAll' });
    window.close();
  };
  
  // Exportar JSON
  document.getElementById('btn-export-json').onclick = async () => {
    await chrome.tabs.sendMessage(tab.id, { action: 'exportJSON' });
    window.close();
  };
  
  // Exportar HTML
  document.getElementById('btn-export-html').onclick = async () => {
    await chrome.tabs.sendMessage(tab.id, { action: 'exportHTML' });
    window.close();
  };
  
  // Borrar datos
  document.getElementById('btn-clear').onclick = async () => {
    if (confirm('¿Borrar todos los datos capturados?')) {
      await chrome.tabs.sendMessage(tab.id, { action: 'clearData' });
      statusEl.textContent = '✓ Datos borrados';
    }
  };
});